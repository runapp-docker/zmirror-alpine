from .colorama import init, Fore
